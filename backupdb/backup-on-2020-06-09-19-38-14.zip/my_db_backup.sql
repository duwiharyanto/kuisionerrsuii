#
# TABLE STRUCTURE FOR: departemen
#

DROP TABLE IF EXISTS `departemen`;

CREATE TABLE `departemen` (
  `departemen_id` int(11) NOT NULL AUTO_INCREMENT,
  `departemen_nama` varchar(150) DEFAULT NULL,
  `departemen_status` bit(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`departemen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (1, 'HR&GA', '1', '2020-06-09 13:56:28');
INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (2, 'Keperawatan', '1', '2020-06-09 13:56:26');
INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (3, 'Keuangan & Akuntansi', '1', '2020-06-09 13:57:10');
INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (4, 'Public Relations, Marketing & IT', '1', '2020-06-09 13:57:28');
INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (5, 'Pelayanan Medik', '1', '2020-06-09 13:57:39');
INSERT INTO `departemen` (`departemen_id`, `departemen_nama`, `departemen_status`, `created_at`) VALUES (6, 'Penunjang Medik', '1', '2020-06-09 13:57:52');


#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `kategori_id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_kategori` text,
  `kategori_periode` text,
  `kategori_status` bit(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kategori_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `kategori` (`kategori_id`, `kategori_kategori`, `kategori_periode`, `kategori_status`, `created_at`) VALUES (1, 'DAFTAR PERTANYAAN \r\nREKAM JEJAK KEGIATAN KARYAWAN \r\nDI LUAR RUMAH SAKIT UNIVERSITAS ISLAM INDONESIA\r\nDALAM UPAYA ANTISIPASI COVID-19\r\n', '(PERIODE TANGGAL 1 - 7 JUNI 2020)', '1', '2020-06-06 09:12:32');


#
# TABLE STRUCTURE FOR: kuisioner
#

DROP TABLE IF EXISTS `kuisioner`;

CREATE TABLE `kuisioner` (
  `kuisioner_id` int(11) NOT NULL AUTO_INCREMENT,
  `kuisioner_nama` varchar(100) DEFAULT NULL,
  `kuisioner_alamatdomisili` varchar(255) DEFAULT NULL,
  `kuisioner_departemen` varchar(255) DEFAULT NULL,
  `kuisioner_departemenid` int(11) DEFAULT NULL,
  `kuisioner_unitkerja` varchar(150) DEFAULT NULL,
  `kuisioner_kategoriid` int(11) DEFAULT NULL,
  `kuisioner_j1` int(11) DEFAULT NULL,
  `kuisioner_j2` int(11) DEFAULT NULL,
  `kuisioner_j3` int(11) DEFAULT NULL,
  `kuisioner_j4` int(11) DEFAULT NULL,
  `kuisioner_j5` int(11) DEFAULT NULL,
  `kuisioner_j6` int(11) DEFAULT NULL,
  `kuisioner_j7` int(11) DEFAULT NULL,
  `kuisioner_j8` int(11) DEFAULT NULL,
  `kuisioner_j9` int(11) DEFAULT NULL,
  `kuisioner_j10` int(11) DEFAULT NULL,
  `kuisioner_j11` int(11) DEFAULT NULL,
  `kuisioner_j12` int(11) DEFAULT NULL,
  `kuisioner_j13` int(11) DEFAULT NULL,
  `kuisioner_j14` int(11) DEFAULT NULL,
  `kuisioner_j15` int(11) DEFAULT NULL,
  `kuisioner_j16` int(11) DEFAULT NULL,
  `kuisioner_j17` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kuisioner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (25, 'duwi haryanto', 'bantul', 'MPRIT', 4, 'IT', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, '2020-06-09 14:29:00');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (31, 'RA ADITYA W. HANURAGA', 'JL. TAMAN SISWA 106, WIROGUNAN, MERGANGSAN, YOGYAKARTA', 'HR & GA', 1, 'HR & GA', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, '2020-06-09 14:25:18');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (32, 'Aulia Rahmawati', 'Kenteng RT 01 Gadingsari Sanden Bantul', 'HRGA', 1, 'Staff Perijinan, Evaluasi dan Pelaporan', 1, 0, 2, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, NULL, '2020-06-09 14:29:18');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (33, 'SUSDIANA', 'JL. MOH YAMIN NO.16, KURAHAN, BANTUL', 'HR & GA', 1, 'PERIZINAN, EVALUASI DAN PELAPORAN', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, '2020-06-09 14:29:19');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (34, 'Rofiq Oksa Mardian', 'Goren RT 1, Bangunjiwo, Kasihan, Bantul, Yogyakarta, 55184', 'HR&GA', 1, 'Diklat', 1, 1, 2, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, NULL, '2020-06-09 14:29:32');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (35, 'Solihin', 'Jetis Daleman RT.03, Gilangharjo Pandak bantul', 'HR', 1, 'Bina Rohani', 1, 1, 2, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, '2020-06-09 14:29:28');
INSERT INTO `kuisioner` (`kuisioner_id`, `kuisioner_nama`, `kuisioner_alamatdomisili`, `kuisioner_departemen`, `kuisioner_departemenid`, `kuisioner_unitkerja`, `kuisioner_kategoriid`, `kuisioner_j1`, `kuisioner_j2`, `kuisioner_j3`, `kuisioner_j4`, `kuisioner_j5`, `kuisioner_j6`, `kuisioner_j7`, `kuisioner_j8`, `kuisioner_j9`, `kuisioner_j10`, `kuisioner_j11`, `kuisioner_j12`, `kuisioner_j13`, `kuisioner_j14`, `kuisioner_j15`, `kuisioner_j16`, `kuisioner_j17`, `created_at`) VALUES (37, 'apt. Ayuningtyas Galuh Purwandityo, S.Farm', 'Perum Nogotirto 3, Jl. Citarum No. B46 Gamping, Sleman, Yogyakarta', 'Penunjang Medik', 6, 'Farmasi', 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, NULL, '2020-06-09 14:29:30');


#
# TABLE STRUCTURE FOR: level
#

DROP TABLE IF EXISTS `level`;

CREATE TABLE `level` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT,
  `level_nama` varchar(255) DEFAULT NULL,
  `level_status` bit(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `level_dashboard` text,
  PRIMARY KEY (`level_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `level` (`level_id`, `level_nama`, `level_status`, `created_at`, `level_dashboard`) VALUES (1, 'Administrator', '1', '2020-02-17 04:22:59', 'dashboard/dashboard');
INSERT INTO `level` (`level_id`, `level_nama`, `level_status`, `created_at`, `level_dashboard`) VALUES (2, 'User', '1', '2020-02-15 15:59:01', 'dashboard/dashboard');
INSERT INTO `level` (`level_id`, `level_nama`, `level_status`, `created_at`, `level_dashboard`) VALUES (3, 'notulen', '1', '2020-02-15 15:53:02', 'notulen/index');
INSERT INTO `level` (`level_id`, `level_nama`, `level_status`, `created_at`, `level_dashboard`) VALUES (11, 'Manajer', '1', '2020-03-28 04:55:34', 'Dashboard/dashboard');
INSERT INTO `level` (`level_id`, `level_nama`, `level_status`, `created_at`, `level_dashboard`) VALUES (13, 'mutu', '1', '2020-06-06 22:30:38', 'Kuisioner');


#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_iduser` int(11) DEFAULT NULL,
  `log_aksi` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log_level` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`log_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=401 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (3, 34, 'login', '2020-01-02 10:40:04', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (21, 4, 'login', '2020-01-02 13:07:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (22, 4, 'logout', '2020-01-02 13:07:55', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (26, 1, 'logout', '2020-01-02 13:08:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (27, 29, 'login', '2020-01-02 13:08:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (28, 1, 'password salah', '2020-01-02 13:12:54', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (29, 1, 'login', '2020-01-02 13:13:03', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (30, 1, 'login', '2020-01-03 10:06:13', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (32, 1, 'login', '2020-01-03 10:45:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (33, 1, 'logout', '2020-01-03 10:48:28', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (34, 1, 'login', '2020-01-03 11:06:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (35, 1, 'logout', '2020-01-03 11:08:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (36, 1, 'login', '2020-01-03 11:08:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (37, 1, 'logout', '2020-01-03 11:08:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (38, 1, 'login', '2020-01-03 11:08:48', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (40, 1, 'login', '2020-01-03 11:10:15', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (41, 1, 'logout', '2020-01-03 11:14:44', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (42, 1, 'login', '2020-01-03 11:17:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (43, 1, 'logout', '2020-01-03 11:18:20', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (44, 1, 'login', '2020-01-03 13:13:46', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (45, 1, 'logout', '2020-01-03 13:16:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (46, 1, 'login', '2020-01-06 12:44:51', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (47, 1, 'logout', '2020-01-07 03:22:39', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (48, 1, 'login', '2020-01-07 03:22:45', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (49, 1, 'login', '2020-01-08 01:18:02', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (50, 1, 'login', '2020-01-09 20:39:02', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (51, 1, 'login', '2020-01-10 17:45:11', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (52, 1, 'logout', '2020-01-10 17:54:19', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (53, 1, 'login', '2020-01-14 17:49:03', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (54, 1, 'logout', '2020-01-14 18:05:20', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (55, 1, 'login', '2020-01-14 18:09:09', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (56, 1, 'logout', '2020-01-14 18:10:13', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (57, 1, 'login', '2020-01-14 18:28:23', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (58, 1, 'logout', '2020-01-14 18:53:38', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (59, 1, 'login', '2020-01-20 20:21:25', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (60, 1, 'login', '2020-01-24 17:46:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (61, 1, 'login', '2020-02-01 16:11:33', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (62, 1, 'logout', '2020-02-01 16:36:46', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (63, 1, 'login', '2020-02-01 16:36:50', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (64, 1, 'logout', '2020-02-01 18:11:06', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (65, 1, 'login', '2020-02-01 18:11:16', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (66, 1, 'logout', '2020-02-01 18:11:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (67, 29, 'password salah', '2020-02-01 18:11:40', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (68, 29, 'login', '2020-02-01 18:11:44', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (69, 1, 'login', '2020-02-05 20:15:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (70, 1, 'logout', '2020-02-05 20:16:05', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (71, 29, 'password salah', '2020-02-05 20:16:08', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (72, 29, 'login', '2020-02-05 20:16:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (73, 1, 'login', '2020-02-06 18:46:40', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (74, 1, 'login', '2020-02-06 23:08:37', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (75, 1, 'login', '2020-02-07 15:43:09', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (76, 1, 'logout', '2020-02-07 17:15:44', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (77, 37, 'login', '2020-02-07 17:15:52', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (78, 37, 'logout', '2020-02-07 17:33:55', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (79, 37, 'login', '2020-02-07 17:34:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (80, 37, 'logout', '2020-02-07 17:35:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (81, 37, 'login', '2020-02-07 17:35:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (82, NULL, 'logout', '2020-02-07 22:55:57', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (83, 1, 'login', '2020-02-07 23:28:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (84, 1, 'logout', '2020-02-07 23:28:07', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (85, 37, 'login', '2020-02-07 23:28:13', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (86, 37, 'login', '2020-02-10 16:54:57', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (87, 37, 'logout', '2020-02-10 17:12:24', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (88, 37, 'login', '2020-02-10 17:12:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (89, 37, 'login', '2020-02-11 17:32:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (90, 37, 'logout', '2020-02-11 18:44:40', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (91, 37, 'login', '2020-02-11 19:58:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (92, 37, 'logout', '2020-02-11 20:07:18', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (93, 1, 'login', '2020-02-11 23:10:34', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (94, 1, 'logout', '2020-02-11 23:13:29', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (95, 1, 'login', '2020-02-11 23:13:41', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (96, 1, 'logout', '2020-02-11 23:15:17', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (97, 1, 'login', '2020-02-15 15:22:06', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (98, 1, 'logout', '2020-02-15 16:07:30', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (99, 37, 'login', '2020-02-15 16:10:27', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (100, 37, 'logout', '2020-02-15 16:10:32', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (101, 1, 'login', '2020-02-15 16:10:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (102, 1, 'logout', '2020-02-15 16:19:29', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (103, 37, 'login', '2020-02-15 16:19:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (104, 37, 'logout', '2020-02-15 16:21:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (105, 1, 'login', '2020-02-15 16:21:40', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (106, 1, 'logout', '2020-02-15 16:22:49', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (107, 1, 'login', '2020-02-15 16:22:52', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (108, 1, 'login', '2020-02-15 17:17:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (109, 1, 'logout', '2020-02-15 17:24:03', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (110, 1, 'login', '2020-02-15 17:24:06', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (111, 1, 'logout', '2020-02-15 17:27:17', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (112, 1, 'login', '2020-02-15 17:27:20', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (113, 1, 'logout', '2020-02-15 17:28:06', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (114, 37, 'login', '2020-02-15 17:28:15', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (115, 37, 'logout', '2020-02-15 17:28:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (116, 37, 'login', '2020-02-15 17:28:51', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (117, 37, 'logout', '2020-02-15 17:29:27', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (118, 1, 'login', '2020-02-15 17:29:30', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (119, 1, 'logout', '2020-02-15 17:31:54', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (120, 1, 'login', '2020-02-15 17:31:59', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (121, 1, 'logout', '2020-02-15 17:33:42', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (122, 1, 'login', '2020-02-15 17:33:52', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (123, 1, 'logout', '2020-02-15 17:39:27', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (124, 36, 'login', '2020-02-15 17:39:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (125, 36, 'logout', '2020-02-15 17:39:44', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (126, 1, 'login', '2020-02-15 17:39:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (127, 36, 'login', '2020-02-15 18:21:09', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (128, 1, 'login', '2020-02-15 19:45:36', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (129, 1, 'logout', '2020-02-15 22:13:59', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (130, 1, 'login', '2020-02-15 22:39:09', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (131, 1, 'logout', '2020-02-16 00:02:04', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (132, 1, 'login', '2020-02-16 02:36:05', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (133, 1, 'login', '2020-02-17 01:53:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (134, 1, 'logout', '2020-02-17 04:20:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (135, 1, 'login', '2020-02-17 04:20:46', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (136, 1, 'logout', '2020-02-17 04:21:14', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (137, 1, 'login', '2020-02-17 04:21:18', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (138, 1, 'logout', '2020-02-17 04:22:10', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (139, 1, 'login', '2020-02-17 04:22:14', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (140, 1, 'logout', '2020-02-17 04:22:39', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (141, 1, 'login', '2020-02-17 04:22:43', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (142, 1, 'logout', '2020-02-17 04:23:03', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (143, 1, 'login', '2020-02-17 04:23:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (144, 1, 'login', '2020-02-17 22:42:39', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (145, 1, 'login', '2020-02-18 18:41:17', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (146, 1, 'login', '2020-02-19 15:35:16', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (147, 1, 'login', '2020-02-19 18:02:02', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (148, 1, 'login', '2020-02-19 22:37:54', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (149, 1, 'logout', '2020-02-19 23:24:59', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (150, 1, 'login', '2020-02-19 23:34:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (151, 1, 'logout', '2020-02-20 00:00:36', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (152, 1, 'login', '2020-02-20 15:13:06', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (153, 1, 'login', '2020-02-25 20:56:36', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (154, 1, 'password salah', '2020-02-26 17:27:11', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (155, 1, 'login', '2020-02-26 17:27:15', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (156, 1, 'login', '2020-02-27 18:02:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (157, 1, 'login', '2020-02-27 22:33:44', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (158, 1, 'login', '2020-02-29 17:11:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (159, 1, 'login', '2020-02-29 21:06:33', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (160, 1, 'login', '2020-02-29 21:25:14', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (161, 1, 'login', '2020-02-29 23:14:54', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (162, 1, 'login', '2020-03-02 18:40:30', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (163, 1, 'logout', '2020-03-02 18:40:42', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (164, 1, 'login', '2020-03-02 18:43:24', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (165, 1, 'logout', '2020-03-02 18:43:29', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (166, 1, 'login', '2020-03-03 23:03:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (167, 1, 'login', '2020-03-04 22:49:08', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (168, 1, 'logout', '2020-03-04 23:47:26', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (169, 1, 'login', '2020-03-05 23:57:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (170, 1, 'login', '2020-03-09 17:34:08', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (171, 1, 'login', '2020-03-09 22:45:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (172, 1, 'login', '2020-03-10 16:49:51', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (173, 1, 'login', '2020-03-10 23:05:27', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (174, 1, 'logout', '2020-03-10 23:44:11', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (175, 1, 'login', '2020-03-11 14:44:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (176, 1, 'logout', '2020-03-11 16:29:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (177, 1, 'login', '2020-03-11 23:09:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (178, 1, 'login', '2020-03-14 17:42:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (179, 1, 'login', '2020-03-14 17:44:21', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (180, 1, 'login', '2020-03-16 22:00:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (181, 1, 'login', '2020-03-17 14:56:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (182, 1, 'logout', '2020-03-17 18:54:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (183, 1, 'login', '2020-03-17 18:55:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (184, 1, 'logout', '2020-03-17 18:57:30', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (185, 1, 'login', '2020-03-17 19:55:04', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (186, 1, 'login', '2020-03-18 18:27:10', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (187, 1, 'logout', '2020-03-18 18:31:27', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (188, 1, 'login', '2020-03-18 22:36:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (189, 1, 'logout', '2020-03-18 23:00:51', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (190, 1, 'login', '2020-03-18 23:06:25', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (191, 1, 'logout', '2020-03-18 23:06:36', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (192, 1, 'login', '2020-03-18 23:17:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (193, 1, 'login', '2020-03-19 15:56:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (194, 1, 'login', '2020-03-19 18:06:57', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (195, 1, 'logout', '2020-03-19 18:48:11', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (196, 1, 'login', '2020-03-19 19:49:47', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (197, 1, 'login', '2020-03-23 20:50:38', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (198, 1, 'logout', '2020-03-23 20:51:08', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (199, 1, 'login', '2020-03-23 20:51:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (200, 1, 'logout', '2020-03-23 21:06:06', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (201, 1, 'login', '2020-03-23 21:09:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (202, 1, 'logout', '2020-03-23 21:09:03', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (203, 1, 'login', '2020-03-23 21:09:08', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (204, 1, 'logout', '2020-03-23 21:09:18', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (205, 1, 'login', '2020-03-23 21:09:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (206, 1, 'logout', '2020-03-23 21:09:44', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (207, 1, 'login', '2020-03-23 21:11:57', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (208, 1, 'logout', '2020-03-23 21:12:16', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (209, 1, 'login', '2020-03-23 21:15:48', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (210, 1, 'logout', '2020-03-23 21:23:01', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (211, 1, 'login', '2020-03-23 21:23:05', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (212, 1, 'logout', '2020-03-23 21:25:48', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (213, 1, 'login', '2020-03-23 21:25:52', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (214, 1, 'login', '2020-03-24 03:56:14', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (215, 1, 'logout', '2020-03-24 05:23:32', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (216, 1, 'login', '2020-03-26 00:11:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (217, 1, 'logout', '2020-03-26 00:48:36', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (222, 1, 'login', '2020-03-26 04:05:39', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (230, NULL, 'logout', '2020-03-28 03:02:26', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (233, 37, 'login', '2020-03-28 04:52:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (234, 37, 'logout', '2020-03-28 04:56:14', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (237, 1, 'login', '2020-05-02 17:56:25', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (241, 1, 'logout', '2020-05-02 18:00:56', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (244, 1, 'login', '2020-05-02 18:08:17', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (245, 1, 'logout', '2020-05-02 18:11:34', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (246, 1, 'login', '2020-05-02 18:11:39', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (247, 1, 'logout', '2020-05-02 19:02:13', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (251, 1, 'login', '2020-05-03 18:37:57', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (252, 1, 'logout', '2020-05-03 18:38:11', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (254, 1, 'login', '2020-05-08 18:37:05', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (255, 1, 'logout', '2020-05-08 19:27:50', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (256, 1, 'login', '2020-05-08 19:27:54', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (257, 1, 'logout', '2020-05-08 19:44:34', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (258, 1, 'login', '2020-05-08 19:49:02', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (259, 1, 'logout', '2020-05-08 19:50:38', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (260, 1, 'login', '2020-05-08 19:54:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (261, 1, 'logout', '2020-05-08 19:54:10', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (262, 1, 'login', '2020-05-08 19:54:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (263, 1, 'logout', '2020-05-08 19:59:51', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (264, 1, 'login', '2020-05-08 20:01:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (265, 1, 'login', '2020-05-17 01:57:54', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (266, 1, 'logout', '2020-05-17 06:11:12', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (267, 1, 'login', '2020-05-17 17:05:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (268, 1, 'login', '2020-05-21 19:12:55', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (269, 1, 'logout', '2020-05-21 20:14:50', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (270, 29, 'login', '2020-05-21 20:14:53', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (271, 29, 'logout', '2020-05-21 20:15:42', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (272, 1, 'login', '2020-05-21 20:16:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (273, 1, 'logout', '2020-05-21 20:16:45', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (274, 29, 'login', '2020-05-21 20:16:53', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (275, 29, 'logout', '2020-05-21 20:23:54', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (276, 29, 'login', '2020-05-21 20:24:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (277, 29, 'logout', '2020-05-21 20:24:14', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (278, 1, 'login', '2020-05-21 20:24:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (279, 1, 'logout', '2020-05-21 20:24:41', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (280, 12, 'login', '2020-05-21 20:24:44', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (281, 12, 'logout', '2020-05-21 20:25:05', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (282, 1, 'login', '2020-05-21 20:25:18', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (283, 1, 'logout', '2020-05-21 21:10:38', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (284, 1, 'login', '2020-05-21 21:10:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (285, 1, 'logout', '2020-05-21 21:12:59', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (286, 29, 'login', '2020-05-21 21:13:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (287, 29, 'logout', '2020-05-21 21:13:50', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (288, 1, 'login', '2020-05-21 21:13:53', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (289, 1, 'logout', '2020-05-21 21:14:15', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (290, 1, 'login', '2020-05-21 21:14:18', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (291, 1, 'logout', '2020-05-21 21:14:37', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (292, 29, 'login', '2020-05-21 21:15:41', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (293, 29, 'logout', '2020-05-21 21:15:58', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (294, 29, 'login', '2020-05-21 21:16:02', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (295, 1, 'login', '2020-05-22 02:27:27', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (296, 1, 'logout', '2020-05-22 04:47:15', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (297, 1, 'login', '2020-05-22 04:47:26', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (298, 1, 'login', '2020-05-29 03:38:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (299, 1, 'logout', '2020-05-29 03:47:46', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (300, 1, 'login', '2020-05-29 03:47:52', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (301, 1, 'login', '2020-05-30 15:03:03', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (302, 1, 'logout', '2020-05-30 16:59:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (303, 1, 'login', '2020-05-30 17:19:23', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (304, 1, 'login', '2020-05-31 00:25:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (305, 1, 'logout', '2020-05-31 00:36:52', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (306, 1, 'login', '2020-05-31 00:36:55', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (307, 1, 'logout', '2020-05-31 00:39:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (308, 1, 'login', '2020-05-31 00:39:46', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (309, 1, 'login', '2020-05-31 00:40:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (310, 1, 'logout', '2020-05-31 00:40:34', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (311, 1, 'login', '2020-05-31 00:40:36', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (312, 1, 'logout', '2020-05-31 00:41:00', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (313, 1, 'login', '2020-05-31 00:41:20', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (314, 1, 'logout', '2020-05-31 00:42:01', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (315, 1, 'login', '2020-05-31 00:42:04', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (316, 1, 'logout', '2020-05-31 00:42:29', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (317, 1, 'login', '2020-05-31 00:42:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (318, 1, 'login', '2020-05-31 00:42:46', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (319, 1, 'login', '2020-05-31 00:43:08', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (320, 1, 'logout', '2020-05-31 00:43:13', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (321, 1, 'login', '2020-05-31 00:43:16', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (322, 1, 'logout', '2020-05-31 00:43:19', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (323, 1, 'login', '2020-05-31 00:43:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (324, 1, 'logout', '2020-05-31 00:45:33', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (325, 1, 'login', '2020-05-31 00:45:35', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (326, 1, 'logout', '2020-05-31 00:45:39', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (327, 1, 'login', '2020-05-31 00:46:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (328, 1, 'logout', '2020-05-31 00:46:06', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (329, 1, 'login', '2020-05-31 00:46:21', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (330, 1, 'login', '2020-05-31 15:51:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (331, 1, 'logout', '2020-05-31 16:21:55', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (332, 1, 'login', '2020-05-31 16:29:14', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (333, 1, 'logout', '2020-05-31 16:32:14', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (334, 1, 'login', '2020-05-31 16:32:39', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (335, 1, 'logout', '2020-05-31 16:44:58', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (336, 29, 'login', '2020-05-31 16:45:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (337, 29, 'logout', '2020-05-31 16:45:39', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (338, 1, 'login', '2020-05-31 16:45:42', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (339, 1, 'login', '2020-06-05 20:56:31', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (340, 1, 'login', '2020-06-06 08:42:15', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (341, 1, 'logout', '2020-06-06 08:52:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (342, 1, 'login', '2020-06-06 08:54:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (343, 1, 'logout', '2020-06-06 10:01:44', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (344, 1, 'login', '2020-06-06 19:51:28', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (345, 1, 'logout', '2020-06-06 19:53:17', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (346, 1, 'login', '2020-06-06 20:11:47', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (347, 1, 'logout', '2020-06-06 22:31:45', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (348, 37, 'login', '2020-06-06 22:31:54', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (349, 37, 'logout', '2020-06-06 22:32:17', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (350, 1, 'login', '2020-06-06 22:32:20', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (351, 1, 'logout', '2020-06-06 22:33:26', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (352, 37, 'login', '2020-06-06 22:33:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (353, 37, 'logout', '2020-06-06 22:41:18', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (354, 1, 'login', '2020-06-06 22:41:24', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (355, 37, 'login', '2020-06-06 22:42:44', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (356, 37, 'logout', '2020-06-06 22:47:27', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (357, 1, 'login', '2020-06-08 06:23:49', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (358, 37, 'login', '2020-06-08 10:32:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (359, 37, 'logout', '2020-06-08 10:33:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (360, 1, 'login', '2020-06-08 10:33:47', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (361, 37, 'login', '2020-06-08 10:34:21', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (362, 1, 'logout', '2020-06-08 10:36:41', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (363, 37, 'login', '2020-06-08 10:56:38', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (364, 37, 'logout', '2020-06-08 11:14:54', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (365, 1, 'login', '2020-06-08 13:07:10', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (366, 37, 'login', '2020-06-08 14:33:33', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (367, 37, 'logout', '2020-06-08 14:35:15', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (368, 37, 'logout', '2020-06-08 14:46:33', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (369, 37, 'login', '2020-06-08 14:47:16', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (370, 37, 'logout', '2020-06-08 14:47:52', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (371, 37, 'login', '2020-06-08 15:19:43', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (372, 37, 'login', '2020-06-09 08:22:38', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (373, 37, 'logout', '2020-06-09 08:28:43', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (374, 37, 'login', '2020-06-09 08:38:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (375, 37, 'login', '2020-06-09 08:45:37', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (376, 37, 'logout', '2020-06-09 08:45:47', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (377, 37, 'login', '2020-06-09 08:46:44', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (378, 37, 'logout', '2020-06-09 08:47:47', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (379, 37, 'login', '2020-06-09 13:33:26', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (380, 37, 'logout', '2020-06-09 13:36:38', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (381, 37, 'login', '2020-06-09 13:36:39', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (382, 1, 'login', '2020-06-09 13:37:04', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (383, 1, 'logout', '2020-06-09 13:38:25', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (384, 1, 'login', '2020-06-09 13:38:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (385, 37, 'logout', '2020-06-09 13:40:34', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (386, 37, 'login', '2020-06-09 13:42:00', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (387, 1, 'logout', '2020-06-09 13:42:18', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (388, 37, 'login', '2020-06-09 14:04:43', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (389, 1, 'login', '2020-06-09 16:14:30', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (390, 1, 'logout', '2020-06-09 16:18:55', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (391, 1, 'login', '2020-06-09 16:19:01', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (392, 1, 'logout', '2020-06-09 18:05:34', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (393, 1, 'login', '2020-06-09 18:07:29', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (394, 1, 'logout', '2020-06-09 18:07:49', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (395, 1, 'login', '2020-06-09 18:10:12', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (396, 1, 'login', '2020-06-09 18:22:05', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (397, 1, 'logout', '2020-06-09 18:23:01', '3');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (398, 1, 'login', '2020-06-09 18:23:07', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (399, 1, 'login', '2020-06-09 18:26:19', '1');
INSERT INTO `log` (`log_id`, `log_iduser`, `log_aksi`, `created_at`, `log_level`) VALUES (400, 1, 'logout', '2020-06-09 18:49:20', '3');


#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_nama` varchar(255) DEFAULT NULL,
  `menu_ikon` varchar(255) DEFAULT NULL,
  `menu_is_mainmenu` varchar(5) DEFAULT NULL,
  `menu_link` varchar(255) DEFAULT NULL,
  `menu_akses_level` varchar(50) DEFAULT NULL,
  `menu_urutan` int(5) DEFAULT NULL,
  `menu_status` varchar(1) DEFAULT NULL,
  `menu_akses` int(2) DEFAULT NULL,
  `menu_baru` int(2) DEFAULT NULL,
  `menu_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (1, 'kontak', 'fas fa-fire', '0', 'Kontak', '2', 2, '1', 1, NULL, 'kontak');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (168, 'setting', 'fas fa-cogs', '0', 'Setting', '1', 96, '1', 1, NULL, 'setting');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (169, 'dashboard', 'fas fa-fire', '0', 'Dashboard', '1', 1, '1', 1, NULL, 'dashboard');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (170, 'hak_akses', 'fas fa-fire', '168', 'Hakakses', '1', 1, '1', 1, NULL, 'hak akses');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (171, 'log', 'fas fa-file', '0', 'Log', '1', 99, '1', 1, NULL, 'log sistem');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (172, 'sistem', 'fas fa-file', '168', 'Sistem', '1', 1, '1', 1, NULL, 'sistem');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (173, 'level', 'fas fa-file', '168', 'Level', '1', 2, '1', 1, NULL, 'level user');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (174, 'user', 'fas fa-user-cog', '168', 'User', '1', 3, '1', 1, NULL, 'user');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (175, 'backup', 'fas fa-file', '168', 'Backup', '1', 4, '1', 1, NULL, 'backup');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (176, 'profil', 'fas fa-user-cog', '0', 'Profil', '1,13', 97, '1', 1, NULL, 'profil user');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (177, 'laporan', 'fas fa-print', '0', 'Laporan', '1,13', 98, '1', 1, NULL, 'laporan');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (178, 'lap_log', 'fas fa-print', '177', 'Laporan/Log', '1', 1, '1', 1, NULL, 'laporan log');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (179, 'lap_user', 'fas fa-print', '177', 'Laporan/User', '1', 2, '1', 1, NULL, 'laporan user');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (180, 'filemanager', 'fas fa-print', '168', 'Filemanager', '1', 5, '1', 1, NULL, 'file manager');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (182, 'kuisioner', 'fas fa-pencil-ruler', '0', 'Kuisioner', '1,13', 3, '1', 1, NULL, 'kuisioner');
INSERT INTO `menu` (`menu_id`, `menu_nama`, `menu_ikon`, `menu_is_mainmenu`, `menu_link`, `menu_akses_level`, `menu_urutan`, `menu_status`, `menu_akses`, `menu_baru`, `menu_label`) VALUES (183, 'lap_kuisioner', 'fas fa-print', '177', 'Laporan/Kuisioner', '1,13', 3, '1', 1, NULL, 'laporan kuisioner');


#
# TABLE STRUCTURE FOR: pertanyaan
#

DROP TABLE IF EXISTS `pertanyaan`;

CREATE TABLE `pertanyaan` (
  `pertanyaan_id` int(11) NOT NULL AUTO_INCREMENT,
  `pertanyaan_pertanyaan` text,
  `pertanyaan_catatan` text,
  `pertanyaan_j1` text,
  `pertanyaan_j2` text,
  `pertanyaan_j3` text,
  `pertanyaan_j4` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pertanyaan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (1, 'APAKAH ANDA MENGUNJUNGI TEMPAT KERAMAIAN KATEGORI 1 (KURANG DARI 10 ORANG) DALAM SEPEKAN INI?', 'Keramaian Kategori 1 adalah berkumpul kurang dari 10 orang. \r\nContoh jenis kegiatan/lokasi kegiatan: \r\nBerkumpul dengan keluarga inti, ronda, tadarus, makan bersama, belanja di warung, kerjabakti, bercocoktanam, dll.\r\n', 'Tidak;0', 'Iya, menggunakan masker;1', 'Iya, tidak menggunakan masker;2', NULL, '2020-06-06 09:03:22');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (2, 'APAKAH ANDA MENGUNJUNGI TEMPAT KERAMAIAN KATEGORI 2 (LEBIH DARI 10 ORANG) DALAM SEPEKAN INI ? ', 'Keramaian Kategori 2 adalah berkumpul lebih dari dan atau sama dengan 10 orang \r\ncontoh jenis kegiatan/lokasi kegiatan:\r\nberkumpul dengan keluarga besar, belanja di pasar/mall, tempat ibadah, tempat olahraga,rapat warga, pengajian, rapat warga, tahlilan, sekolah, pernikahan, bioskop/nonton bareng, restoran/kafe, dll)\r\n', 'Tidak;0', 'Iya, menggunakan masker;2', 'Iya, tidak menggunakan masker;4', NULL, '2020-06-06 09:03:21');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (3, 'APAKAH DALAM SEPEKAN INI MENGALAMI GEJALA DEMAM?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:20');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (4, 'APAKAH DALAM SEPEKAN INI MENGALAMI GEJALA FLU/PILEK?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:20');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (5, 'APAKAH DALAM SEPEKAN INI MENGALAMI GEJALA BATUK?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:19');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (6, 'APAKAH DALAM SEPEKAN INI MENGALAMI GEJALA NYERI TENGGOROKAN/TELAN?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:18');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (7, 'APAKAH DALAM SEPEKAN INI MENGALAMI GEJALA SESAK NAFAS?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:17');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (8, 'APAKAH DALAM SEPEKAN INI ANDA MELAKUKAN PERJALANAN KELUAR KOTA/KELUAR NEGERI?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:14');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (9, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SEBELUM DAN SESUDAH MAKAN?', NULL, 'Tidak;0', 'Iya;1', NULL, NULL, '2020-06-06 09:03:16');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (10, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SESUDAH SELESAI DARI KAMAR MANDI (BAK / BAB)?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:49:46');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (11, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SEBELUM DAN SESUDAH MEMAKAI MASKER?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:50:27');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (12, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SESUDAH MEMEGANG BARANG (UANG, PAKET, MAKANAN) DARI LUAR RUMAH?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:50:46');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (13, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SEBELUM MENYENTUH WAJAH?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:51:00');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (14, 'APAKAH ANDA SELALU MELAKUKAN CUCI TANGAN DENGAN SABUN SETELAH BERKEGIATAN SESUDAH BEPERGIAN DARI TEMPAT KERAMAIAN KATEGORI 1?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:51:59');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (15, 'APAKAH ANDA MANDI SETELAH KELUAR DARI RUMAH UNTUK BERKEGIATAN DARI TEMPAT KERAMAIAN KATEGORI 2?', NULL, 'Tidak;1', 'Iya;0', NULL, NULL, '2020-06-06 08:51:57');
INSERT INTO `pertanyaan` (`pertanyaan_id`, `pertanyaan_pertanyaan`, `pertanyaan_catatan`, `pertanyaan_j1`, `pertanyaan_j2`, `pertanyaan_j3`, `pertanyaan_j4`, `created_at`) VALUES (16, 'BAGAIMANA POLA TIDUR ANDA DALAM SEPEKAN INI?', NULL, 'a.	Tidur kurang dari 4 jam sehari ;1', 'b.	Tidur 4-8 jam sehari ;0', NULL, NULL, '2020-06-08 10:41:41');


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_namasistem` varchar(255) DEFAULT NULL,
  `setting_namatempat` text,
  `setting_alamat` text,
  `setting_email` varchar(100) DEFAULT NULL,
  `setting_notlp` varchar(20) DEFAULT NULL,
  `setting_logo` text,
  `setting_tagline` varchar(255) DEFAULT NULL,
  `setting_namapemilik` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`setting_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `setting` (`setting_id`, `setting_namasistem`, `setting_namatempat`, `setting_alamat`, `setting_email`, `setting_notlp`, `setting_logo`, `setting_tagline`, `setting_namapemilik`) VALUES (1, 'Novasys', 'Array Motion', 'Jl.bantul Km 10', 'haryanto.duwi@gmail.com', '085725818424', '3663fdabf683f180798ed04287b0c189.png', 'System X', 'Duwi haryantoo');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `user_password` text CHARACTER SET latin1,
  `user_nama` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `user_level` int(5) DEFAULT NULL,
  `user_terdaftar` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_email` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `user_status` bit(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_foto` text,
  `user_dashboard` text,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 1, '2018-09-29 00:00:00', 'Admin@gmail.com', '1', '2020-05-01 21:21:52', '42c47f96f8b16e06bd0457c52cd2825e.jpg', 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (3, 'haryanto', '8e7173cb9b869db115f77688e70b8ff7', 'haryanto duwi', 3, '2018-10-21 00:00:00', 'admin@gmail.com', '1', '2020-05-01 21:21:49', NULL, 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (12, 'mita', 'bae3d929b274a4cd35c38fe92f059f1a', 'mita', 1, '2019-12-30 19:38:01', 'mitaduwi@gmail.com', '1', '2020-05-01 21:21:47', NULL, 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (29, 'duwi', '21232f297a57a5a743894a0e4a801fc3', 'duwi haryanto', 1, '2019-12-30 21:14:49', 'haryanto.duwi@gmail.com', '1', '2020-05-01 21:21:43', 'fc0d4f41ae0b26f20e8ebc480f5189c0.jpg', 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (35, 'mika', '07af613eea059030daaed3bde1fd1ce7', 'mika', 1, '2019-12-31 14:45:32', 'mika@gmail.com', '1', '2020-01-02 17:15:30', NULL, 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (36, 'hanabi', 'd43fcce13f4c88fd28c279cc2859f579', 'hanabi', 3, '2020-01-07 00:23:31', 'hanabi@gmail.com', '1', '2020-01-07 00:23:31', NULL, 'Dashboard');
INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_nama`, `user_level`, `user_terdaftar`, `user_email`, `user_status`, `created_at`, `user_foto`, `user_dashboard`) VALUES (37, 'mutu', '374beb0c5da1e3912d391b64705da2a1', 'mutu', 13, '2020-06-06 22:31:40', 'mutu@rsuii.co.id', '1', '2020-06-06 22:31:40', 'e0e9a7a5c0fb8e62a2af1c5fe74f57a3.jpg', 'Kuisioner');


